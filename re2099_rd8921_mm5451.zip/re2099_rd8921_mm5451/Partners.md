# COS375 Project 2

### Group (work in groups of 2, 3, or 4 people, adjust the number of lines as needed)

Max Machado - mm5451 mm5451@princeton.edu
Rayan Elahmadi - re2099 re2099@princeton.edu
Bobby Diaz - rd8921 rd8921@princeton.edu

## Time Investment

### Approximately how many hours did it take you to complete this assignment?

70

### How many additional test cases did you write to test your implementation?
15

## Challenges Encountered

### Did you encounter any serious problems? If yes, please describe (e.g spec was unclear).

We had issue with trying to get our nops to be properly classified.

## Additional Comments

### Write any other comments here.

- [comment_1]
- [comment_2]

### If you decided to experiment with some more advanced branch prediction policies, describe them below.

N/A

## Help Information

## Generative AI.

- If you used generative AI for help with this project, please describe which one and what prompt you used.
- Refer to the syllabus generative AI tools policy: the policy for use of AI assistants parallels that for human collaboration. Remember that you cannot directly generate code that you submit. 
- Write "N/A" if you did not use generative AI for any help during this project.

We used generative AI to help us come up with ideas for use in our test cases. We also used AI to help in debugging by discussing our errors and what potential causes might be.

## Acknowledgement of Original Work

### Write and sign the following student acknowledgment of original work.

> For your signature, type /s/, followed by your name.
> 
> Here is an example:
>
>> This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Ada Lovelace

This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Max Machado
This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Rayan Elahmadi
This programming assignment represents my own work in accordance with University regulations and the course syllabus.  /s/ Bobby Diaz


