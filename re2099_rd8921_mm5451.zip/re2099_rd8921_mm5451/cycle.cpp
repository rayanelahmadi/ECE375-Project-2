#include "cycle.h"

#include <climits>
#include <iostream>
#include <memory>
#include <string>

#include "Utilities.h"
#include "cache.h"
#include "simulator.h"

static Simulator* simulator = nullptr;
static Cache* iCache = nullptr;
static Cache* dCache = nullptr;
static std::string output;
static uint64_t cycleCount = 0;

static uint64_t PC = 0;
// useful for cache miss handling
static uint64_t iMissRemaining = 0;
static bool iMissActive = false;  
static uint64_t dMissRemaining = 0;
static bool dMissActive = false;
static bool dMissIsLoad = false;  
static Simulator::Instruction latchedMemInst;
// previous data cache access tracking
static bool prevDValid = false;
static uint64_t prevDAddr = 0;
static CacheOperation prevDOp = CACHE_READ;
// previous instruction cache PC
static uint64_t prevICPC = (uint64_t)-1;
// flush handling for exception (pending from previous cycle)
static bool pendingFlush = false;
static uint64_t pendingFlushPC = 0;
// useful for statistics
static uint64_t loadUseStallCount = 0;
static uint64_t committedDin = 0;
static uint64_t lastCommittedPC = UINT64_MAX;

Simulator::Instruction doneInst;

Simulator::Instruction nop(StageStatus status) {
    Simulator::Instruction n;
    n.instruction = 0x00000013;
    n.isLegal = true;
    n.isNop = true;
    n.status = status;
    return n;
}

static struct PipelineInfo {
    Simulator::Instruction ifInst = nop(IDLE);
    Simulator::Instruction idInst = nop(IDLE);
    Simulator::Instruction exInst = nop(IDLE);
    Simulator::Instruction memInst = nop(IDLE);
    Simulator::Instruction wbInst = nop(IDLE);
} pipelineInfo;

// initialize the simulator
Status initSimulator(CacheConfig& iCacheConfig, CacheConfig& dCacheConfig, MemoryStore* mem,
                     const std::string& output_name) {
    output = output_name;
    simulator = new Simulator();
    simulator->setMemory(mem);
    iCache = new Cache(iCacheConfig, I_CACHE);
    dCache = new Cache(dCacheConfig, D_CACHE);
    doneInst = nop(IDLE);
    cycleCount = 0;
    PC = 0;
    iMissRemaining = dMissRemaining = 0;
    iMissActive = dMissActive = dMissIsLoad = false;
    prevDValid = false;
    prevDAddr = 0;
    prevDOp = CACHE_READ;
    prevICPC = (uint64_t)-1;
    pendingFlush = false;
    pendingFlushPC = 0;
    loadUseStallCount = committedDin = 0;
    lastCommittedPC = UINT64_MAX;
    pipelineInfo = {};
    pipelineInfo.ifInst = nop(IDLE);
    pipelineInfo.idInst = nop(IDLE);
    pipelineInfo.exInst = nop(IDLE);
    pipelineInfo.memInst = nop(IDLE);
    pipelineInfo.wbInst = nop(IDLE);
    return SUCCESS;
}

bool hazard(const Simulator::Instruction& dstInst, uint64_t srcReg) {
    return dstInst.writesRd && dstInst.rd != 0 && dstInst.rd == srcReg;
}

// run the simulator for a certain number of cycles
// return SUCCESS if reaching desired cycles.
// return HALT if the simulator halts on 0xfeedfeed

Status runCycles(uint64_t cycles) {
    uint64_t count = 0;
    auto status = SUCCESS;
    PipeState pipeState = {0};

    while (cycles == 0 || count < cycles) {
        pipeState.cycle = cycleCount;
        count++;
        cycleCount++;

        // check for pending flush from previous cycle
        // supposed to handle exception redirection and squashing
        bool applyFlush = pendingFlush;
        uint64_t flushPC = pendingFlushPC;
        pendingFlush = false;
        
        if (applyFlush) {
            // make sure to squash instructions in IF and ID (they were younger than the excepting instruction)
            PC = flushPC;
            iMissRemaining = 0;
        }

        // useful for hazard detection?
        Simulator::Instruction prevIDInst = pipelineInfo.idInst;
        Simulator::Instruction prevEXInst = pipelineInfo.exInst;
        Simulator::Instruction prevMEMInst = pipelineInfo.memInst;

        bool stall = false;
        bool flush = false;  // flush for branches (immediate effect)
        bool branchStall = false;
        // memStall is true if the dcache miss is active
        bool memStall = dMissActive;

        // check load use stalls (don't worry about x0)
        bool loadUseStallTriggered = false;
        if (prevEXInst.readsMem && prevEXInst.rd != 0 && !prevEXInst.isNop && prevEXInst.isLegal &&
            prevEXInst.status != BUBBLE && prevEXInst.status != SQUASHED) {
            bool hazardRs1 = (prevEXInst.rd == prevIDInst.rs1 && prevIDInst.readsRs1);
            bool hazardRs2 = (prevEXInst.rd == prevIDInst.rs2 && prevIDInst.readsRs2);
            if (hazardRs1 || hazardRs2) {
                // special cases
                bool isStore = prevIDInst.writesMem;
                bool isOnlyStoreDataHazard = (!hazardRs1) && hazardRs2 && isStore;
                if (!isOnlyStoreDataHazard) {
                    stall = true;
                    loadUseStallTriggered = true;
                }
            }
        }

        // let's check arithmetic branch stall
        if (prevEXInst.writesRd && prevEXInst.rd != 0 && !prevEXInst.isNop && !prevEXInst.readsMem &&
            (prevIDInst.opcode == OP_BRANCH || prevIDInst.opcode == OP_JALR)) {
            if ((prevIDInst.rs1 == prevEXInst.rd && prevIDInst.readsRs1) ||
                (prevIDInst.rs2 == prevEXInst.rd && prevIDInst.readsRs2)) {
                stall = true;
            }
        }

        // load branch stall if branch in ID stage depends on load in MEM stage
        if (prevMEMInst.readsMem && prevMEMInst.writesRd && prevMEMInst.rd != 0 && !prevMEMInst.isNop &&
            (prevIDInst.opcode == OP_BRANCH || prevIDInst.opcode == OP_JALR)) {
            if ((prevMEMInst.rd == prevIDInst.rs1 && prevIDInst.readsRs1) ||
                (prevMEMInst.rd == prevIDInst.rs2 && prevIDInst.readsRs2)) {
                stall = true;
            }
        }

        // WB STAGE HERE
        Simulator::Instruction prevMEM = pipelineInfo.memInst;

        if (dMissActive) {
            pipelineInfo.wbInst = nop(BUBBLE);
        } else {
            pipelineInfo.wbInst = simulator->simWB(prevMEM);

            // determine WB status based on what came from MEM stage I think?
            if (prevMEM.isNop && prevMEM.status == IDLE) {
                pipelineInfo.wbInst = nop(IDLE);
            } else if (prevMEM.isNop && prevMEM.status == SQUASHED) {
                pipelineInfo.wbInst = nop(SQUASHED);
            } else if (pipelineInfo.wbInst.isNop) {
                pipelineInfo.wbInst.status = BUBBLE;
            } else {
                pipelineInfo.wbInst.status = NORMAL;
            }
        }

        // count committed instructions (includes HALT)
        if (!pipelineInfo.wbInst.isNop && pipelineInfo.wbInst.isLegal) {
            committedDin++;
        }
        if (pipelineInfo.wbInst.isHalt) {
            status = HALT;
        }

        // MEM STAGE HERE
        Simulator::Instruction prevEX = pipelineInfo.exInst;
        bool newDMissThisCycle = false;

        // if already stalled from previous cycle, mem should get the latched instruction.
        Simulator::Instruction memCandidate = memStall ? latchedMemInst : prevEX;

        // d cache check
        bool willAccessDCache = (memCandidate.readsMem || memCandidate.writesMem) &&
                                !memCandidate.isNop && memCandidate.isLegal &&
                                memCandidate.status != BUBBLE && memCandidate.status != SQUASHED;
        CacheOperation opType = memCandidate.writesMem ? CACHE_WRITE : CACHE_READ;

        if (!dMissActive && willAccessDCache) {
            if (!prevDValid || memCandidate.memAddress != prevDAddr || opType != prevDOp) {
                prevDValid = true;
                prevDAddr = memCandidate.memAddress;
                prevDOp = opType;

                if (!dCache->access(memCandidate.memAddress, opType)) {
                    dMissActive = true;
                    dMissRemaining = 0;
                    dMissIsLoad = memCandidate.readsMem;
                    latchedMemInst = memCandidate;
                    newDMissThisCycle = true;
                }
            }
        } else if (dMissActive) {
            dMissRemaining++;
        }

        if (dMissActive) {
            // check if the miss is resolving this cycle
            if (dMissRemaining > dCache->config.missLatency - 1) {
                pipelineInfo.memInst = simulator->simMEM(latchedMemInst);
            } else {
                // still waiting for cache so keep showing the latched instruction
                pipelineInfo.memInst = latchedMemInst;
            }
            pipelineInfo.memInst.status = NORMAL;
        } else {
            // cache hit or miss resolved 
            pipelineInfo.memInst = simulator->simMEM(memCandidate);
            if (memCandidate.isNop && memCandidate.status == IDLE) {
                pipelineInfo.memInst = nop(IDLE);
            } else if (memCandidate.isNop && memCandidate.status == SQUASHED) {
                pipelineInfo.memInst = nop(SQUASHED);
            } else if (pipelineInfo.memInst.isNop) {
                pipelineInfo.memInst.status = BUBBLE;
            } else {
                pipelineInfo.memInst.status = NORMAL;
            }
        }

        memStall = dMissActive && !newDMissThisCycle;


        // EX STAGE HERE
        Simulator::Instruction prevID = pipelineInfo.idInst;
        
        // if flush being applied this cycle I think the instruction in ID was the illegal excepting one
        if (applyFlush) {
            pipelineInfo.exInst = nop(SQUASHED);
        } else if (memStall) {
            // do nothing
        } else if (stall) {
            if (loadUseStallTriggered) {
                loadUseStallCount++;
            }
            if (prevID.isNop && prevID.status == IDLE) {
                pipelineInfo.exInst = nop(IDLE);
            } else {
                pipelineInfo.exInst = nop(BUBBLE);
            }
        } else {
            // take care of forwarding
            if (hazard(pipelineInfo.memInst, prevID.rs1)) {
                prevID.op1Val = pipelineInfo.memInst.readsMem ? pipelineInfo.memInst.memResult
                                                              : pipelineInfo.memInst.arithResult;
            } else if (hazard(pipelineInfo.wbInst, prevID.rs1)) {
                prevID.op1Val = pipelineInfo.wbInst.readsMem ? pipelineInfo.wbInst.memResult
                                                            : pipelineInfo.wbInst.arithResult;
            } else if (hazard(doneInst, prevID.rs1)) {
                prevID.op1Val = doneInst.readsMem ? doneInst.memResult : doneInst.arithResult;
            }
            if (hazard(pipelineInfo.memInst, prevID.rs2)) {
                prevID.op2Val = pipelineInfo.memInst.readsMem ? pipelineInfo.memInst.memResult
                                                              : pipelineInfo.memInst.arithResult;
            } else if (hazard(pipelineInfo.wbInst, prevID.rs2)) {
                prevID.op2Val = pipelineInfo.wbInst.readsMem ? pipelineInfo.wbInst.memResult
                                                            : pipelineInfo.wbInst.arithResult;
            } else if (hazard(doneInst, prevID.rs2)) {
                prevID.op2Val = doneInst.readsMem ? doneInst.memResult : doneInst.arithResult;
            }

            if (prevID.isNop) {
                if (prevID.status == IDLE) {
                    pipelineInfo.exInst = nop(IDLE);
                } else if (prevID.status == SQUASHED) {
                    pipelineInfo.exInst = nop(SQUASHED);
                } else {
                    pipelineInfo.exInst = nop(BUBBLE);
                }
            } else {
                pipelineInfo.exInst = simulator->simEX(prevID);
                if (pipelineInfo.exInst.isNop) {
                    pipelineInfo.exInst.status = BUBBLE;
                } else {
                    pipelineInfo.exInst.status = NORMAL;
                }
            }
        }

        // ID STAGE HERE
        Simulator::Instruction prevIF = pipelineInfo.ifInst;

        if (applyFlush) {
            pipelineInfo.idInst = nop(SQUASHED);
        } else if (stall && !memStall) {
            if (prevIDInst.opcode == OP_BRANCH || prevIDInst.opcode == OP_JALR) {
                if (hazard(pipelineInfo.memInst, prevIDInst.rs1)) {
                    prevIDInst.op1Val = pipelineInfo.memInst.readsMem ? pipelineInfo.memInst.memResult
                                                                      : pipelineInfo.memInst.arithResult;
                } else if (hazard(pipelineInfo.wbInst, prevIDInst.rs1)) {
                    prevIDInst.op1Val = pipelineInfo.wbInst.readsMem ? pipelineInfo.wbInst.memResult
                                                                    : pipelineInfo.wbInst.arithResult;
                } else if (hazard(doneInst, prevIDInst.rs1)) {
                    prevIDInst.op1Val = doneInst.readsMem ? doneInst.memResult : doneInst.arithResult;
                }
                if (hazard(pipelineInfo.memInst, prevIDInst.rs2)) {
                    prevIDInst.op2Val = pipelineInfo.memInst.readsMem ? pipelineInfo.memInst.memResult
                                                                      : pipelineInfo.memInst.arithResult;
                } else if (hazard(pipelineInfo.wbInst, prevIDInst.rs2)) {
                    prevIDInst.op2Val = pipelineInfo.wbInst.readsMem ? pipelineInfo.wbInst.memResult
                                                                    : pipelineInfo.wbInst.arithResult;
                } else if (hazard(doneInst, prevIDInst.rs2)) {
                    prevIDInst.op2Val = doneInst.readsMem ? doneInst.memResult : doneInst.arithResult;
                }
                pipelineInfo.idInst = simulator->simNextPCResolution(prevIDInst);

                

                if (!pipelineInfo.idInst.isHalt && pipelineInfo.idInst.nextPC != prevIDInst.PC + 4) {
                    flush = true;
                    PC = pipelineInfo.idInst.nextPC;
                }
            }
        } else if (!(stall || memStall)) {
            if (prevIF.isNop) {
                if (pipelineInfo.idInst.isNop && pipelineInfo.idInst.status == IDLE) {
                    if (prevIF.status != IDLE) {
                        pipelineInfo.idInst = nop(BUBBLE);
                    }
                } else {
                    if (prevIF.status == SPECULATIVE) {
                        pipelineInfo.idInst = nop(SQUASHED);
                    } else {
                        pipelineInfo.idInst = nop(BUBBLE);
                    }
                }
            } else {
                Simulator::Instruction newIDInst = simulator->simID(prevIF);

                // illegal instruction was detected in ID so schedule exception for next cycle
                if (!newIDInst.isNop && !newIDInst.isLegal) {
                    pendingFlush = true;
                    pendingFlushPC = 0x8000;
                    pipelineInfo.idInst = newIDInst;
                    pipelineInfo.idInst.status = NORMAL;
                } else {
                    {
                        // forward to branch operands if ready
                        if (newIDInst.opcode == OP_BRANCH || newIDInst.opcode == OP_JALR) {
                            if (hazard(pipelineInfo.exInst, newIDInst.rs1)) {
                                newIDInst.op1Val = pipelineInfo.exInst.readsMem ? pipelineInfo.exInst.memResult
                                                                                 : pipelineInfo.exInst.arithResult;
                            } else if (hazard(pipelineInfo.memInst, newIDInst.rs1)) {
                                newIDInst.op1Val = pipelineInfo.memInst.readsMem ? pipelineInfo.memInst.memResult
                                                                                   : pipelineInfo.memInst.arithResult;
                            } else if (hazard(pipelineInfo.wbInst, newIDInst.rs1)) {
                                newIDInst.op1Val = pipelineInfo.wbInst.readsMem ? pipelineInfo.wbInst.memResult
                                                                                : pipelineInfo.wbInst.arithResult;
                            } else if (hazard(doneInst, newIDInst.rs1)) {
                                newIDInst.op1Val = doneInst.readsMem ? doneInst.memResult : doneInst.arithResult;
                            }

                            if (hazard(pipelineInfo.exInst, newIDInst.rs2)) {
                                newIDInst.op2Val = pipelineInfo.exInst.readsMem ? pipelineInfo.exInst.memResult
                                                                                 : pipelineInfo.exInst.arithResult;
                            } else if (hazard(pipelineInfo.memInst, newIDInst.rs2)) {
                                newIDInst.op2Val = pipelineInfo.memInst.readsMem ? pipelineInfo.memInst.memResult
                                                                                   : pipelineInfo.memInst.arithResult;
                            } else if (hazard(pipelineInfo.wbInst, newIDInst.rs2)) {
                                newIDInst.op2Val = pipelineInfo.wbInst.readsMem ? pipelineInfo.wbInst.memResult
                                                                                : pipelineInfo.wbInst.arithResult;
                            } else if (hazard(doneInst, newIDInst.rs2)) {
                                newIDInst.op2Val = doneInst.readsMem ? doneInst.memResult : doneInst.arithResult;
                            }
                            newIDInst = simulator->simNextPCResolution(newIDInst);
                        }

                        pipelineInfo.idInst = newIDInst;
                        if (pipelineInfo.idInst.isNop) {
                            pipelineInfo.idInst.status = BUBBLE;
                        } else {
                            pipelineInfo.idInst.status = NORMAL;
                        }

                        if (!pipelineInfo.idInst.isHalt && pipelineInfo.idInst.nextPC != prevIF.PC + 4) {
                            flush = true;
                            PC = pipelineInfo.idInst.nextPC;
                        }
                    }
                }
            }
        }

        // IF STAGE HERE
        if (applyFlush) {
            bool iHit = iCache->access(PC, CACHE_READ);
            if (!iHit) {
                iMissRemaining = iCache->config.missLatency;
                iMissActive = true;
                pipelineInfo.ifInst = nop(NORMAL);
                pipelineInfo.ifInst.PC = PC;
            } else {
                pipelineInfo.ifInst = simulator->simIF(PC);
                pipelineInfo.ifInst.status = NORMAL;
                PC = PC + 4;
                iMissActive = false;
            }
        } else if (stall || branchStall || memStall) {
            if (flush) {
                iMissActive = false;
                iMissRemaining = 0;
                pipelineInfo.ifInst.status = SPECULATIVE;
            } else if (iMissRemaining > 0) {
                iMissRemaining--;
                if (iMissRemaining == 0 && iMissActive) {
                    pipelineInfo.ifInst = simulator->simIF(PC);
                    pipelineInfo.ifInst.status = NORMAL;
                    PC = PC + 4;  
                    iMissActive = false;
                }
            }
        } else if (flush) {
            bool iHit = iCache->access(PC, CACHE_READ);
            if (!iHit) {
                iMissRemaining = iCache->config.missLatency;
                iMissActive = true;
            } else {
                iMissActive = false;
            }
            // the speculative instruction is squashed
            pipelineInfo.ifInst = nop(SPECULATIVE);
            pipelineInfo.ifInst.PC = pipelineInfo.idInst.PC + 4;
        } else {
            if (iMissRemaining > 0) {
                iMissRemaining--;
                if (iMissRemaining == 0 && iMissActive) {
                    pipelineInfo.ifInst = simulator->simIF(PC);
                    pipelineInfo.ifInst.status = NORMAL;
                    PC = PC + 4;
                    iMissActive = false;
                } else {
                    pipelineInfo.ifInst = nop(NORMAL);
                    pipelineInfo.ifInst.PC = PC;
                }
            } else {
                bool iHit = iCache->access(PC, CACHE_READ);
                if (!iHit) {
                    iMissRemaining = iCache->config.missLatency;
                    iMissActive = true;
                    pipelineInfo.ifInst = nop(NORMAL);
                    pipelineInfo.ifInst.PC = PC;
                } else {
                    pipelineInfo.ifInst = simulator->simIF(PC);
                    pipelineInfo.ifInst.status = NORMAL;
                    if (pipelineInfo.idInst.opcode == OP_BRANCH) {
                        pipelineInfo.ifInst.status = SPECULATIVE;
                    }
                    PC = PC + 4;
                }
            }
        }

        if (pipelineInfo.memInst.memException) {
            pendingFlush = true;
            pendingFlushPC = 0x8000;
        }

        if (!pipelineInfo.ifInst.isNop) {
            if (pipelineInfo.ifInst.status == BUBBLE || pipelineInfo.ifInst.status == IDLE) {
                pipelineInfo.ifInst.status = NORMAL;
            }
        }

        doneInst = pipelineInfo.wbInst;

        if (dMissActive && dMissRemaining > dCache->config.missLatency - 1) {
            dMissRemaining = 0;
            dMissActive = false;
            prevDValid = false;  
        }

        if (status == HALT) {
            break;
        }
    }

    pipeState.ifPC = pipelineInfo.ifInst.PC;
    pipeState.ifStatus = pipelineInfo.ifInst.status;
    pipeState.idInstr = pipelineInfo.idInst.instruction;
    pipeState.idStatus = pipelineInfo.idInst.status;
    pipeState.exInstr = pipelineInfo.exInst.instruction;
    pipeState.exStatus = pipelineInfo.exInst.status;
    pipeState.memInstr = pipelineInfo.memInst.instruction;
    pipeState.memStatus = pipelineInfo.memInst.status;
    pipeState.wbInstr = pipelineInfo.wbInst.instruction;
    pipeState.wbStatus = pipelineInfo.wbInst.status;

    dumpPipeState(pipeState, output);

    return status;
}

Status runTillHalt() {
    Status status;
    while (true) {
        status = static_cast<Status>(runCycles(1));
        if (status == HALT) break;
    }
    return status;
}

// dump the state of the simulator
Status finalizeSimulator() {
    uint64_t icHits = iCache ? iCache->getHits() : 0;
    uint64_t icMisses = iCache ? iCache->getMisses() : 0;
    uint64_t dcHits = dCache ? dCache->getHits() : 0;
    uint64_t dcMisses = dCache ? dCache->getMisses() : 0;
    SimulationStats stats{committedDin, cycleCount, icHits, icMisses, dcHits, dcMisses, loadUseStallCount};
    dumpSimStats(stats, output);
    simulator->dumpRegMem(output);
    return SUCCESS;
}
